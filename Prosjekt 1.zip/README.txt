Tema for denne nettsida er blåbær. Dette er eg takknemlig for sidan det er veldig godt. 

KRAV #1: I websiden skal det benyttes CSS for å stile elementene og vi forventer at det er lagt ned litt arbeid i å lage en visuelt tiltalende side. 
    LØYSING: I nettsida har lagt inn mykje arbeid i fargevalg på tekstar, rammer bakgrunnar, eg har jobba ein del med plassering av divs og ulike andre element, har brukt ulike fontar frå Google, små CSS animasjonar og meir. Eg har jobba fram eit design som eg og folk eg har vist nettsida til er fornøgde med. 

KRAV #2: I websiden skal du bruke CSS Flexbox layout for å posisjonere elementene.
    LØYSING: For å oppfylle dette kravet har eg brukt flexbox på delen av nettsida om «andre bær». Desse knappane/bæra vil plassere seg utfrå skjermstørrelse. Noko flexbox har eg også lagt inn i navbar og under delen for ingrediensar og framgangsmåte på oppskrifter. 

KRAV #3: Bruk Javascript for gjøre noen ett eller flere elementer på siden interaktiv
    LØYSING: For å oppfylle denne delen har eg lagt inn knappar for å endre «fane» med dei ulike oppskriftene. Eg har også lagt til ein bildeslide der det er brukt JavaScript i delen for «plukking».

KRAV #4: Siden skal ha et favicon (sjekk på web hva dette er) 
    LØYSING: I head i koden har eg lagt inn eit favicon for blåbær. Denne ser ein i fana i nettlesaren der favicon skal vises. 

KRAV #5: Siden skal være gyldig HTML (kunne valideres av W3C markup validator) og være testet for forskjellige weblesere
    LØYSING: Etter å ha kjørt W3C markup validator på HTMLen på nettsida var det kun iframe frå Spotify som ville gje error. Dette er ikkje noko eg får gjort så mykje med og eg går utfrå at iframen deira er såpass mykje jobba med at dette ikkje skal vere eit problem. Ellers får eg ingen varslar eller feilmeldingar. Har testa nettsida i Google Chrome, Opera Internet Browser, Opera Neon, Microsoft Edge og Internet Explorer, og opplever at nettsida oppfører seg likt i alle nettlesarane. 
KRAV #6: CSS og Javascript skal være i egne filer
    LØYSING: Alt av CSS kan ein finne i style.css som er linka opp mot HTML fila. JavaScript er delt opp i to eigne filer der bildesliden sin kode ligg i pictureslide.js og koden for dei ulike fanene med oppskrifter ligg i buttons.js.